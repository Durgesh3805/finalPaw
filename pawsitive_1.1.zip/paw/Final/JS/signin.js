document.addEventListener("DOMContentLoaded", function () {
  var popupContainer = document.getElementById("popup-container");
  var popupOverlay = document.getElementById("popup-overlay");
  var signinLink = document.getElementById("signin-link");

  signinLink.addEventListener("click", function (event) {
    event.preventDefault();
    popupContainer.style.display = "block";
    popupOverlay.style.display = "block";
  });

  popupOverlay.addEventListener("click", function () {
    popupContainer.style.display = "none";
    popupOverlay.style.display = "none";
  });
});
