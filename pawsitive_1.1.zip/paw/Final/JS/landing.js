document.getElementById('toggle').addEventListener('change', function() {
    document.getElementById('sidebar').classList.toggle('open');
});